<form action="cadastram.php" method="POST">
	Nome: <input type="text" name="nome_app" maxlength="30"><br />
	Telefone: <input type="text" name="telefone_app" maxlength="11"><br />
	E-mail: <input type="text" name="email_app" maxlength="30"><br />
	Endereco: <input type="text" name="endereco_app" maxlength="50"><br />
	Especialidade: <input type="text" name="especialidade_app" maxlength="20"><br />
	
	<input type="submit" value="Cadastrar">
</form>