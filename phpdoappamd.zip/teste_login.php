<form action="logar.php" method="POST">

	Cartao: <input type="text" name="cartao_app"><br />
	
	<input type="submit" value="Logar">
</form>