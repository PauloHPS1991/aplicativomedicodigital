<form action="cadastrar.php" method="POST">
	Nome: <input type="text" name="nome_app" maxlength="30"><br />
	Telefone: <input type="text" name="telefone_app" maxlength="11"><br />
	E-mail: <input type="text" name="email_app" maxlength="30"><br />
	Cartao: <input type="text" name="cartao_app"maxlength="20"><br />
	
	<input type="submit" value="Cadastrar">
</form>